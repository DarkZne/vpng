package com.nerdtech.nerdvpn_codecanyon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
