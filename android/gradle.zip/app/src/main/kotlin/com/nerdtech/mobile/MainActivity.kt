package com.nerdtech.mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
